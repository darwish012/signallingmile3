package com.example.voipfinal

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.rtp.AudioCodec
import android.net.rtp.AudioGroup
import android.net.rtp.AudioStream
import android.net.rtp.RtpStream
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.InetAddress

class MainActivity : AppCompatActivity() {
    private lateinit var audioGroup: AudioGroup
    private lateinit var audioStream: AudioStream

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val localIpEditText: EditText = findViewById(R.id.localIpEditText)
        val remoteIpEditText: EditText = findViewById(R.id.ipEditText)
        val portEditText: EditText = findViewById(R.id.portEditText)
        val connectButton: Button = findViewById(R.id.startCallButton)

        // Use ActivityResultContracts for permission handling
        val requestPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
                if (isGranted) {
                    // Permission is granted, proceed with your audio setup
                    setupAudioCommunicationAsync(
                        localIpEditText.text.toString(),
                        remoteIpEditText.text.toString(),
                        portEditText.text.toString()
                    )
                } else {
                    // Permission is not granted, handle it (e.g., show a message to the user)
                    // You may want to show a Toast or provide some feedback to the user
                }
            }

        connectButton.setOnClickListener {
            // Check if the RECORD_AUDIO permission is granted
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                // Permission is already granted, proceed with your audio setup
                setupAudioCommunicationAsync(
                    localIpEditText.text.toString(),
                    remoteIpEditText.text.toString(),
                    portEditText.text.toString()
                )
            } else {
                // Permission is not granted, request it
                requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private inner class SetupAudioTask : AsyncTask<String, Void, AudioStream>() {

        override fun doInBackground(vararg params: String): AudioStream? {
            try {
                val localIp = params[0]
                val remoteIp = params[1]
                val remotePort = params[2].toIntOrNull()

                // Create and return the AudioStream
                return setupAudioCommunication(localIp, remoteIp, remotePort)
            } catch (e: Exception) {
                // Log the exception details
                Log.e("SetupAudioTask", "Exception in doInBackground: ${e.message}", e)

                return null
            }
        }

        override fun onPostExecute(audioStream: AudioStream?) {
            // Use the audioStream object as needed
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun setupAudioCommunicationAsync(localIp: String, remoteIp: String, remotePort: String) {
        val task = SetupAudioTask()
        task.execute(localIp, remoteIp, remotePort)
        task.get() // Ensure the task completes before proceeding
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun setupAudioCommunication(localIp: String, remoteIp: String, remotePort: Int?): AudioStream {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION

        audioGroup = AudioGroup(this)
        audioGroup.mode = AudioGroup.MODE_NORMAL

        val localAddress = InetAddress.getByName(localIp)
        val remoteAddress = InetAddress.getByName(remoteIp)

        val audioStream = AudioStream(localAddress)
        var localport= audioStream.localPort
        audioStream.codec = AudioCodec.PCMU
        audioStream.mode = RtpStream.MODE_NORMAL

        if (remotePort != null) {
            try {
                val context = applicationContext // Get the application context

                // Check if the context is not null before using it
                if (context != null) {
                    runOnUiThread {
                        try {
                            audioStream.associate(remoteAddress, remotePort)
                            audioStream.join(audioGroup)
                            Toast.makeText(context, "succeed to establish connection:", Toast.LENGTH_SHORT).show()

                        } catch (e: Exception) {
                            Log.e("AudioCommunication", "Exception in setupAudioCommunication join: ${e.message}", e)
                            Toast.makeText(context, "Failed to establish connection: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    Log.e("AudioCommunication", "Application context is null")
                }
            } catch (e: Exception) {
                Log.e("AudioCommunication", "Exception in setupAudioCommunication: ${e.message}", e)
            }
        } else {
            Log.e("AudioCommunication", "Remote port is null")
            runOnUiThread {
                Toast.makeText(this, "Failed to establish connection: Remote port is null", Toast.LENGTH_SHORT).show()
            }
            // Handle the case where remotePort is null
            throw IllegalArgumentException("Remote port is null")
        }

        return audioStream
    }}